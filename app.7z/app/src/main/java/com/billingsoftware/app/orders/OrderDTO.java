package com.billingsoftware.app.orders;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDTO {

	
	public Long customerId;
	
	public String customerName;

	public Double totalGrossAmount;
	
	public Double netAmount;
	
	public String gstPerCentage;
	
	public Double  csgstAmount;
	
	public Double  sgstAmount;
	
	private Double  transportAmount;
	
	private Double  netAfterRemovingTransportAmount;
	public List<ProductDTO> productDTO;
}

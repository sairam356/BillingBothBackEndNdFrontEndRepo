package com.billingsoftware.app.orders;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsoftware.app.customer.Customer;
import com.billingsoftware.app.customer.CustomerRepository;
import com.billingsoftware.app.products.Products;
import com.billingsoftware.app.products.ProductsRepository;

@Service
public class OrdersService {

	public static final String ACCEPTED_STATUS = "ACCEPTED";
	public static final String IN_PROGRSS_STATUS = "IN_PROGRESS";
	public static final String COMPLETED_STATUS = "COMPLETED";

	@Autowired
	OrdersRepository ordersRepository;

	@Autowired
	OrderDetailsRepository orderDetailsRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	OrderDetailsService orderDetailsService;

	@Autowired
	ProductsRepository productRepository;

	public Long addOrdersInfo(OrderDTO orders) {

		Orders orderObj = new Orders();
		orderObj.setCustomerName(orders.getCustomerName());
		orderObj.setCustomerId(orders.getCustomerId());
		orderObj.setGstPerCentage(orders.getGstPerCentage());
		orderObj.setCsgstAmount(orders.getCsgstAmount());
		orderObj.setSgstAmount(orders.getSgstAmount());
		orderObj.setNetAmount(orders.getNetAmount());
		orderObj.setTotalGrossAmount(orders.getTotalGrossAmount());
		orderObj.setNetAfterRemovingTransportAmount(orders.getNetAfterRemovingTransportAmount());
		orderObj.setTransportAmount(orders.getTransportAmount());
		orderObj.setStatus("ACCEPTED");
		orderObj.setCredt(new Date());
		orderObj.setUpdDt(new Date());

		Orders entityObj = ordersRepository.save(orderObj);
		orderDetailsService.saveOrderDetialsFromOrder(entityObj.getOriderId(), orders.getProductDTO());

		return entityObj.getOriderId();

	}

	public Orders updateOrdersInfo(Orders orders) {
           
		return ordersRepository.save(orders);

	}

	public List<Orders> getOrdersList() {

		return ordersRepository.findAll();
	}

	public int deleteOrders(Long id) {
		Optional<Orders> findById = ordersRepository.findById(id);
		Orders Orders = findById.get();
		ordersRepository.delete(Orders);
		return 0;
	}

	public OrderResponseDTO getOrders(Long id) {

		Optional<Orders> findById = ordersRepository.findById(id);
		Orders orders = findById.get();
		OrderResponseDTO orderResponseDTO = new OrderResponseDTO();
		orderResponseDTO.setOrders(orders);

		List<OrderDetails> findByOrderId = orderDetailsRepository.findByOrderId(id);
		List<OrderDetailsRespDTO> respList = new ArrayList<>();
		findByOrderId.forEach(x -> {
			OrderDetailsRespDTO respDto = new OrderDetailsRespDTO();
			Long productId = x.getProductId();
			Optional<Products> findById2 = productRepository.findById(productId);
			Products products = findById2.get();
			respDto.setOrderDetails(x);
			respDto.setProdut(products);
			respList.add(respDto);
		});

		Optional<Customer> findById2 = customerRepository.findById(orders.getCustomerId());
		Customer customer = findById2.get();
		orderResponseDTO.setOrderRSPDetails(respList);
		orderResponseDTO.setCustomer(customer);

		return orderResponseDTO;
	}

	public Map<String, Integer> getOrderCount() {
		int acceptedCount = 0;
		int inprogressCount = 0;
		int completedCount = 0;
		Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.DATE, -30);

		List<Orders> orderList = ordersRepository.findByCredtBetween(cal.getTime(), new Date());

		for(Orders obj :orderList) {

			if (obj.getStatus().equals(ACCEPTED_STATUS)) {
				  acceptedCount = acceptedCount+1;

			} else if (obj.getStatus().equals(IN_PROGRSS_STATUS)) {
				  inprogressCount = inprogressCount+1;

			} else if (obj.getStatus().equals(COMPLETED_STATUS)) {
				  completedCount =completedCount+1;

			}

		};
		
		Map<String,Integer> obj = new HashMap<>();
		obj.put(ACCEPTED_STATUS, acceptedCount);
		obj.put(IN_PROGRSS_STATUS, inprogressCount);
		obj.put(COMPLETED_STATUS, completedCount);

		return obj;
	}
}

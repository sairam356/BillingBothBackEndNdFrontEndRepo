package com.billingsoftware.app.products;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.billingsoftware.app.customer.Customer;

@Service
@Transactional
public class ProductsService {
	
	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	static String[] HEADERs = { "Id", "Title", "Description", "Published" };
	static String SHEET = "Tutorials";

	@Autowired
	ProductsRepository productsRepository;

	public Products addProductsInfo(Products Products) {

		return productsRepository.save(Products);

	}

	public Products updateProductsInfo(Products Products) {

		return productsRepository.save(Products);

	}

	public List<Products> getProductsList() {

		return productsRepository.findAll();
	}

	public int deleteProducts(Long id) {
		Optional<Products> findById = productsRepository.findById(id);
		Products Products = findById.get();
		productsRepository.delete(Products);
		return 0;
	}

	public Products getProducts(Long id) {

		Optional<Products> findById = productsRepository.findById(id);
		Products Products = findById.get();
		return Products;
	}
	
	public void save(MultipartFile file) {
		try {
			List<Products> productList = excelToProduct(file.getInputStream());
			productsRepository.saveAll(productList);
		} catch (IOException e) {
			throw new RuntimeException("fail to store excel data: " + e.getMessage());
		}
	}

	private List<Products> excelToProduct(InputStream inputStream) {

		List<Products> productList = new ArrayList<Products>();
		try {
			Workbook workbook = new XSSFWorkbook(inputStream);

			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rows = sheet.iterator();

			int rowNumber = 0;
			while (rows.hasNext()) {
				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();

				Products products = new Products();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();

					switch (cellIdx) {
					case 0:
						products.setProductName(currentCell.getStringCellValue());
						break;
						
					case 1:
						products.setProductCode(currentCell.getStringCellValue());
						break;

					case 2:
						products.setHsn(currentCell.getStringCellValue());
						break;

					case 3:
						products.setPack(currentCell.getStringCellValue());
						break;

					case 4:
						products.setBasePrice(currentCell.getNumericCellValue());
						break;
					case 5:
						products.setMeasurement(currentCell.getStringCellValue());
						break;

					case 6:
						products.setStockQunty((long)currentCell.getNumericCellValue());
						break;

					case 7:
						products.setMrpPrice(currentCell.getNumericCellValue());
						break;

					default:
						break;
					}

					cellIdx++;
				}
				
				
				products.setCredt(new Date());
				productList.add(products);
			}

			workbook.close();

			return productList;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}
}

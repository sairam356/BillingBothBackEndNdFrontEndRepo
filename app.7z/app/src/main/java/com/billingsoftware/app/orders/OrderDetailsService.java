package com.billingsoftware.app.orders;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsoftware.app.products.Products;
import com.billingsoftware.app.products.ProductsRepository;
import com.billingsoftware.app.stockManagment.StockRepository;
import com.billingsoftware.app.stockManagment.Stocks;

@Service
public class OrderDetailsService {

	@Autowired
	OrderDetailsRepository orderDetailsRepository;

	@Autowired
	ProductsRepository productRepository;
	
	@Autowired
	StockRepository stockRepository;

	public void addOrderDetailsInfo(OrderDetails OrderDetails) {

		orderDetailsRepository.save(OrderDetails);
	}

	public OrderDetails updateOrderDetailsInfo(OrderDetails OrderDetails) {

		return orderDetailsRepository.save(OrderDetails);

	}

	public List<OrderDetails> getOrderDetailsList() {

		return orderDetailsRepository.findAll();
	}

	public int deleteOrderDetails(Long id) {
		Optional<OrderDetails> findById = orderDetailsRepository.findById(id);
		OrderDetails OrderDetails = findById.get();
		orderDetailsRepository.delete(OrderDetails);
		return 0;
	}

	public OrderDetails getOrderDetails(Long id) {

		Optional<OrderDetails> findById = orderDetailsRepository.findById(id);
		OrderDetails orderDetails = findById.get();
		return orderDetails;
	}

	public void saveOrderDetialsFromOrder(Long orderId, List<ProductDTO> productDTO) {

		productDTO.forEach(obj -> {
			Long pqnty = obj.getQnty();
			OrderDetails orderDetails = new OrderDetails();
			orderDetails.setOrderId(orderId);
			orderDetails.setProductId(obj.getProductId());
			orderDetails.setProductName(obj.getProductName());
			orderDetails.setProductBasePrice(obj.getProductBasePrice());
			orderDetails.setQnty(obj.getQnty());
			orderDetails.setCalualteAmount(obj.getCalualteAmount());
			orderDetails.setGstPerCentage(obj.getGstPerCentage());
            orderDetails.setModifiedPrice(obj.getModifiedPrice());
			updateProductRealtedStock(pqnty, obj.getProductId());
		    manageStockData(orderId,obj);
			addOrderDetailsInfo(orderDetails);
            
		});
		

	}

	public void updateProductRealtedStock(Long qnty, Long productId) {
		Optional<Products> findById = productRepository.findById(productId);
		Products productObj = findById.get();
		Long updatedQunty = productObj.getStockQunty() - qnty;
		productObj.setStockQunty(updatedQunty);

	}
	
	public void manageStockData(Long orderId, ProductDTO obj) {
		Stocks stock = new Stocks();
		stock.setInvoice(orderId);
		stock.setProductId(obj.getProductId());
		stock.setProductName(obj.getProductName());
		stock.setCredt(new Date());
		stock.setSentQnty(obj.getQnty());
		stockRepository.save(stock);
		
	}
}

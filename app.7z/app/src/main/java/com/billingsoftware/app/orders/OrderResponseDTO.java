package com.billingsoftware.app.orders;

import java.util.List;

import com.billingsoftware.app.customer.Customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderResponseDTO {

	
	Orders orders;
	Customer customer;
	List<OrderDetailsRespDTO> orderRSPDetails;
}

package com.billingsoftware.app.orders;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class OrderDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderDetailsId;
	
	private Long orderId;
	
    private Long productId;
	
	private String productName;
	
	private Long qnty;
	
	private Double calualteAmount;
	
	private String gstPerCentage;
	
	private Double  productBasePrice;
	
	private Double  modifiedPrice;
	
	

}

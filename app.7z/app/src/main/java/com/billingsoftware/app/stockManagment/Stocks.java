package com.billingsoftware.app.stockManagment;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.billingsoftware.app.orders.Orders;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Stocks {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long stockId;
	
	private Long invoice;

	private Long productId;
	
	private String productName;
	
	private Long receivedQnty;
	
	private Long sentQnty;
	
	private Date credt;
	private Date updt;

}

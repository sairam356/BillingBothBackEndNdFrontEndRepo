package com.billingsoftware.app.customer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/cust")
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@PostMapping
	public Customer addCustomerInfo(@RequestBody Customer customer) {

		return customerService.addCustomerInfo(customer);

	}

	@PutMapping
	public Customer updateCustomerInfo(@RequestBody Customer customer) {

		return customerService.updateCustomerInfo(customer);

	}

	@GetMapping
	public List<Customer> getCustomerList() {

		return customerService.getCustomerList();

	}

	@GetMapping("/{id}")
	public Customer getCustomerById(@PathVariable Long id) {

		return customerService.getCustomer(id);
	}

	@DeleteMapping("/{id}")
	public int deleteCustomer(@PathVariable Long id) {

		return customerService.deleteCustomer(id);
	}

	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file) {
		String message = "";

		try {
			customerService.save(file);

			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			return message;
		} catch (Exception e) {
			return message = "Could not upload the file: " + file.getOriginalFilename() + "!";

		}

	}

}

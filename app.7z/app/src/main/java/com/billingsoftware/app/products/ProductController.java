package com.billingsoftware.app.products;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductsService productsService;
	 
	@PostMapping
	public Products addProductsInfo(@RequestBody Products products) {
		
		
		return productsService.addProductsInfo(products);
	
	}
	 
	@PutMapping
	public Products updateProductsInfo(@RequestBody Products products) {
		
		
		return productsService.updateProductsInfo(products);
		
	}
	 
	@GetMapping
	public List<Products>  getProductsList(){
		
		return productsService.getProductsList();

}
	
	@GetMapping("/{id}")
	public Products  getProductsById(@PathVariable Long id){
		
		return productsService.getProducts(id);
	}
	 
	@DeleteMapping("/{id}")
	public int  deleteProducts(@PathVariable Long id) {
		
		
		return productsService.deleteProducts(id);
	}
	
	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file) {
		String message = "";

		try {
			productsService.save(file);

			message = "Uploaded the file successfully: " + file.getOriginalFilename();
			return message;
		} catch (Exception e) {
			return message = "Could not upload the file: " + file.getOriginalFilename() + "!";

		}

	}
	

	

}

package com.billingsoftware.app.orders;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductDTO {
	
	
	public Long productId;
	
	public String productName;
	
	public Long qnty;
	
	public Double calualteAmount;
	
	public String gstPerCentage;
	
	public Double productBasePrice;
	
	public Double  modifiedPrice;

}

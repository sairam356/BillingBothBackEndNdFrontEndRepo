package com.billingsoftware.app.stockManagment;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billingsoftware.app.products.Products;
import com.billingsoftware.app.products.ProductsRepository;

@Service
public class StockService {

	@Autowired
	StockRepository stockRepository;

	@Autowired
	ProductsRepository productsRepository;

	public Stocks addStocksInfo(Stocks stocks) {

		stocks.setCredt(new Date());
		Stocks stockObj = stockRepository.save(stocks);

		Optional<Products> findById = productsRepository.findById(stockObj.getProductId());
		Products productObj = findById.get();
		long getQynty = productObj.getStockQunty() == null ? 0 : productObj.getStockQunty();
		Long updateQnty = getQynty + stocks.getReceivedQnty();
		productObj.setStockQunty(updateQnty);
		productsRepository.save(productObj);

		return stockObj;

	}

	public Stocks updateStocksInfo(Stocks stocks) {
		stocks.setCredt(new Date());
		return stockRepository.save(stocks);

	}

	public List<Stocks> getStocksList() {

		return stockRepository.findAll();
	}

	public int deleteStocks(Long id) {
		Optional<Stocks> findById = stockRepository.findById(id);
		Stocks Stocks = findById.get();
		stockRepository.delete(Stocks);
		return 0;
	}

	public Stocks getStocks(Long id) {

		Optional<Stocks> findById = stockRepository.findById(id);
		Stocks Stocks = findById.get();
		return Stocks;
	}

	public List<Stocks> getStocksByProductCode(String productCode) {
		List<Stocks> stocks = null;
		List<Products> findByProductCode = productsRepository.findByProductCode(productCode);
		if (findByProductCode.size() > 0) {
			Products product = findByProductCode.get(0);
			stocks = stockRepository.findByProductId(product.getProductId());
			return stocks;
		}

		return stocks;

	}
}

package com.billingsoftware.app.products;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductInfoDTO {

	public String productName;
	public String productCode;
	public Double mrpPrice;

}

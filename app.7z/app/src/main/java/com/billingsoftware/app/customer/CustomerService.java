package com.billingsoftware.app.customer;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class CustomerService {

	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	static String[] HEADERs = { "Id", "Title", "Description", "Published" };
	static String SHEET = "Tutorials";

	@Autowired
	CustomerRepository customerRepository;

	public Customer addCustomerInfo(Customer customer) {

		return customerRepository.save(customer);

	}

	public Customer updateCustomerInfo(Customer customer) {

		return customerRepository.save(customer);

	}

	public List<Customer> getCustomerList() {

		return customerRepository.findAll();
	}

	public int deleteCustomer(Long id) {
		Optional<Customer> findById = customerRepository.findById(id);
		Customer customer = findById.get();
		customerRepository.delete(customer);
		return 0;
	}

	public Customer getCustomer(Long id) {

		Optional<Customer> findById = customerRepository.findById(id);
		Customer customer = findById.get();
		return customer;
	}

	public void save(MultipartFile file) {
		try {
			List<Customer> customerList = excelToCustomer(file.getInputStream());
			customerRepository.saveAll(customerList);
		} catch (IOException e) {
			throw new RuntimeException("fail to store excel data: " + e.getMessage());
		}
	}

	private List<Customer> excelToCustomer(InputStream inputStream) {

		List<Customer> customerList = new ArrayList<Customer>();
		try {
			Workbook workbook = new XSSFWorkbook(inputStream);

			Sheet sheet = workbook.getSheetAt(0);
			Iterator<Row> rows = sheet.iterator();

			int rowNumber = 0;
			while (rows.hasNext()) {
				Row currentRow = rows.next();

				// skip header
				if (rowNumber == 0) {
					rowNumber++;
					continue;
				}

				Iterator<Cell> cellsInRow = currentRow.iterator();

				Customer customer = new Customer();

				int cellIdx = 0;
				while (cellsInRow.hasNext()) {
					Cell currentCell = cellsInRow.next();

					switch (cellIdx) {
					case 0:
						customer.setCustomerName(currentCell.getStringCellValue());
						break;

					case 1:
						customer.setEmail(currentCell.getStringCellValue());
						break;

					case 2:
						 String str = NumberToTextConverter.toText(currentCell.getNumericCellValue());
						customer.setMobileNumber(str+"");
						break;

					case 3:
						customer.setGSTNumber(currentCell.getStringCellValue());
						break;
					case 4:
						customer.setCompanyName(currentCell.getStringCellValue());
						break;

					case 5:
						customer.setAddress(currentCell.getStringCellValue());
						break;

					case 6:
						customer.setCity(currentCell.getStringCellValue());
						break;

					case 7:
						 String str1 = NumberToTextConverter.toText(currentCell.getNumericCellValue());
						customer.setPincode(str1);
						break;
					case 8:
						customer.setDepartment(currentCell.getStringCellValue());
						break;

					default:
						break;
					}

					cellIdx++;
				}
				
				
                customer.setCredt(new Date());
				customerList.add(customer);
			}

			workbook.close();

			return customerList;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		}
	}

}

package com.billingsoftware.app.orders;

import java.util.Date;

import com.billingsoftware.app.products.Products;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetailsRespDTO {

	public OrderDetails orderDetails;
	public Products produt;
}

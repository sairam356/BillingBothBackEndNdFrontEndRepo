package com.billingsoftware.app.stockManagment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/stock")
public class StockController {

	@Autowired
	StockService stocksService;

	@PostMapping
	public Stocks addstocksInfo(@RequestBody Stocks stocks) {

		return stocksService.addStocksInfo(stocks);

	}

	@PutMapping
	public Stocks updatestocksInfo(@RequestBody Stocks stocks) {

		return stocksService.updateStocksInfo(stocks);

	}

	@GetMapping
	public List<Stocks> getstocksList() {

		return stocksService.getStocksList();

	}

	@GetMapping("/{id}")
	public Stocks getstocksById(@PathVariable Long id) {

		return stocksService.getStocks(id);
	}
	
	@GetMapping("/code/{productCode}")
	public List<Stocks> getstocksByProductCode(@PathVariable String productCode) {

		return stocksService.getStocksByProductCode(productCode);
	}
	

	@DeleteMapping("/{id}")
	public int deletestocks(@PathVariable Long id) {

		return stocksService.deleteStocks(id);
	}

}

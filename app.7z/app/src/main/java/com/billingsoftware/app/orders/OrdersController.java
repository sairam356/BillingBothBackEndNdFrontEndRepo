package com.billingsoftware.app.orders;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrdersController {
	
	@Autowired
	OrdersService ordersService;
	
	@PostMapping
	public Long addOrdersInfo(@RequestBody OrderDTO orderDTO) {
		
		
		return ordersService.addOrdersInfo(orderDTO);
	
	}
	 
	@PutMapping
	public Orders updateOrdersInfo(@RequestBody Orders orders) {
		
		
		return ordersService.updateOrdersInfo(orders);
		
	}
	
	@GetMapping
	public List<Orders>  getOrdersList(){
		
		return ordersService.getOrdersList();

}
	
	@GetMapping("/{id}")
	public OrderResponseDTO  getOrdersById(@PathVariable Long id){
		
		return ordersService.getOrders(id);
	}

	@DeleteMapping("/{id}")
	public int  deleteOrders(@PathVariable Long id) {
		
		
		return ordersService.deleteOrders(id);
	}
	 
	@GetMapping("/getOrderCount")
	 public Map<String,Integer> getOrderCount(){
		 
		 
		 return ordersService.getOrderCount();
		 
	 }

}

 $(document).ready(function(){


 getCustomerData();


 getProductData();


 getOrderData();


$("#editProduct").click(function(event) {
    event.preventDefault();
var x = $("form").serializeArray();
var obj ={}
$.each(x, function(i, field) {
obj[field.name] = field.value;
          console.log(field.name + ":"
                    + field.value + " ");
});



     $.ajax({
          url: "http://localhost:9090/product", 
         type: "PUT",
         dataType: "json",
         contentType: "application/json; charset=utf-8",
         data: JSON.stringify(obj),
        success: function (result) {
                   console.log(result);
                    var url = "/productlist.html";
                   $(location).attr('href',url);
         },
        error: function (err) {
            console.log(err);

       }
   }); 
});  





$("#addproduct").click(function(event) {
            event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");

  });


 console.log(obj);

             $.ajax({
                  url: "http://localhost:9090/product", 
                 type: "POST",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(obj),
                success: function (result) {
                           console.log(result);      
                            var url = "/productlist.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
 });

 $("#createOrder").click(function(event){
event.preventDefault();
var   orderObj  = JSON.parse(sessionStorage.getItem("createOrdeObj"));

var netAmount = orderObj.netAmount.toString();
 console.log(netAmount);
   var amount =0;
   var amountSpilt = netAmount.split(".");
   var afterDot = parseInt(amountSpilt[1]);
   if(afterDot>50){
       amount = (amount+ parseFloat(amountSpilt[0]) +1).toFixed(2);

   }else{
      amount = (amount+ parseFloat(amountSpilt[0]));
   }

  orderObj.netAmount = amount;
  



 $.ajax({
                  url: "http://localhost:9090/order", 
                 type: "POST",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(orderObj),
                success: function (result) {
                           console.log(result);      
                            var url = "/orderdetails.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

  
 });

 $("#calcualteTrasportAmount").click(function(event){
    event.preventDefault();
      var tranPortVal = $('#trasportAmount').val();
      var ToFloatTranportAmount = parseFloat(tranPortVal);
      var orderObj =  JSON.parse(sessionStorage.getItem("createOrdeObj"));
      console.log(orderObj);
      var netAmount = orderObj.netAmount;
      var netPayAmount = (orderObj.netAmount - ToFloatTranportAmount).toFixed(2);
      orderObj.transportAmount = ToFloatTranportAmount;
      orderObj.netAfterRemovingTransportAmount = netPayAmount;
      console.log(orderObj);
      sessionStorage.setItem("createOrdeObj", JSON.stringify(orderObj));
      $("#showAllValues2").show();
      $("#netPayAmount").val(netPayAmount);
      $("#showHRAfterNetPayAmount").show();
        
   
 })

 $("#calcualteAllAmount").click(function(event){
  event.preventDefault();
  
  var  finalObj ={}
  

 var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
 if(productAryList.length>0){

    finalObj.productDTO = productAryList;
 var   custObj = JSON.parse(sessionStorage.getItem("selectedCustomerId"));
  finalObj.customerId = custObj.customerId;
  finalObj.customerName = custObj.customerName;
 var totalAmount =0.0;

  for(let i =0;i<productAryList.length;i++){

       totalAmount = totalAmount+ parseFloat(productAryList[i].calualteAmount);
  }
 finalObj.totalGrossAmount = totalAmount;


 var avgPerCentage = parseFloat(custObj.gstPerCentage/2);
 var totalPercentage = parseFloat(custObj.gstPerCentage);

 var totalGstAmount = ((totalAmount*totalPercentage) / 100).toFixed(2);
console.log(avgPerCentage+ "  "+custObj.gstPerCentage+"  "+totalGstAmount);

 finalObj.netAmount = (totalAmount - totalGstAmount).toFixed(2) ;
 finalObj.csgstAmount= (totalGstAmount/2).toFixed(2);
 finalObj.sgstAmount=   (totalGstAmount/2).toFixed(2)  ;
 finalObj.gstPerCentage =custObj.gstPerCentage;
   $("#showButton").show();
   $("#showAllValues").show();
   $("#showAllValues1").show();

        $('#showHRAfterAmountCal').show();
 
   sessionStorage.setItem("createOrdeObj", JSON.stringify(finalObj));
   console.log(finalObj);
   $('#totalAmountId').val(finalObj.totalGrossAmount);
   $('#netAmountId').val(finalObj.netAmount);
   $('#csgstAmountId').val(finalObj.csgstAmount);
   $('#sgstAmountId').val( finalObj.sgstAmount);
   $("#totalGSTAmount").val(totalGstAmount);


}

 });

 $("#addCustomer").click(function(event) {
            event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });


 console.log(obj);

             $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "POST",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(obj),
                success: function (result) {
                           console.log(result);      
                            var url = "/customerlist.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
 });   


 $("#editCustomer").click(function(event) {
            event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });


 console.log(obj);

             $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "PUT",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                 data: JSON.stringify(obj),
                success: function (result) {
                           console.log(result);
                            var url = "/customerlist.html";
                           $(location).attr('href',url);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
 });  



 $("#addProductToOrder").click(function(event){

    event.preventDefault();
  var x = $("form").serializeArray();
  var obj ={}
 $.each(x, function(i, field) {
     obj[field.name] = field.value;
                  console.log(field.name + ":"
                            + field.value + " ");
  });

var custObj ={};
var  customerFiled = obj.customerName;
var customer = customerFiled.split("?");
custObj.customerId = customer[0];
custObj.customerName = customer[1];
custObj.gstPerCentage = obj.gstPerCentage;
custObj.modifiedPrice = obj.modifiedPrice;
sessionStorage.setItem("selectedCustomerId", JSON.stringify(custObj));
 var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
    if(productAryList.length>0){
        var checkDuplicate = true;
          for (let i = 0; i < productAryList.length; i++) {
               if(productAryList[i].productId == obj.productName){
                  checkDuplicate = false;
                   break;
               }

          }

     if(checkDuplicate){
        
        var pOrderObj ={};
        pOrderObj.productId = obj.productName;
        pOrderObj.qnty = obj.qnty;
        pOrderObj.gstPerCentage = obj.gstPerCentage;
         $.ajax({
                  url: "http://localhost:9090/product/"+pOrderObj.productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    pOrderObj.productName = result.productName;
                    pOrderObj.productCode = result.productCode;
                    pOrderObj.productBasePrice = result.basePrice;
                    pOrderObj.modifiedPrice = obj.modifiedPrice;
                    var calcualtePrice =0;
                    if(obj.modifiedPrice == 0)
                    {
                       
                          var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.productBasePrice).toFixed(2);
                         console.log(calcualtePrice);
                    }else{

                         var qunatity = parseInt(pOrderObj.qnty);
                           var mPrice = parseFloat(pOrderObj.modifiedPrice);
                          calcualtePrice = (qunatity * mPrice).toFixed(2);
                         console.log(calcualtePrice);

                    }

                    pOrderObj.calualteAmount = calcualtePrice;
                    productAryList.push(pOrderObj);

                    console.log(productAryList);

                    sessionStorage.setItem("orderProductArry", JSON.stringify(productAryList));

                    var tableData="";
                     for (let i = 0; i < productAryList.length; i++) {
                        var index = (i+1);
                    tableData = tableData+'<tr><th scope="row">'+index+'</th>'+'<td>'+productAryList[i].productName+
                                        '</td><td>'+productAryList[i].productCode+'</td><td>'+productAryList[i].productBasePrice+'</td><td>'+ productAryList[i].qnty+'</td><td>'+
                                        productAryList[i].calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+productAryList[i].productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);

                    }
                 },
                error: function (err) {
                    console.log(err);

               }
           });
          
       }

    } else {

        var pArray =[];
        var pOrderObj ={};
        pOrderObj.productId = obj.productName;
        pOrderObj.qnty = obj.qnty;
        pOrderObj.gstPerCentage = obj.gstPerCentage;


    $.ajax({
                  url: "http://localhost:9090/product/"+pOrderObj.productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    pOrderObj.productName = result.productName;
                    pOrderObj.productCode = result.productCode;
                    pOrderObj.productBasePrice = result.basePrice;
                    pOrderObj.modifiedPrice = obj.modifiedPrice;
                     var calcualtePrice =0;
                    if(obj.modifiedPrice == 0)
                    {
                       
                          var qunatity = parseInt(pOrderObj.qnty);
                          calcualtePrice = (qunatity * pOrderObj.productBasePrice).toFixed(2);
                         console.log(calcualtePrice);
                    }else{

                         var qunatity = parseInt(pOrderObj.qnty);
                         var mPrice = parseFloat(pOrderObj.modifiedPrice);
                          calcualtePrice = (qunatity * mPrice).toFixed(2);
                         console.log(calcualtePrice);

                    }         
                    pOrderObj.calualteAmount = calcualtePrice;
                    pArray.push(pOrderObj);

                    console.log(pArray);

                    sessionStorage.setItem("orderProductArry", JSON.stringify(pArray));

                    var tableData="";
                    tableData = tableData+'<tr><th scope="row">'+1+'</th>'+'<td>'+pOrderObj.productName+
                                        '</td><td>'+pOrderObj.productCode+'</td><td>'+pOrderObj.productBasePrice+'</td><td>'+ pOrderObj.qnty+'</td><td>'+
                                        pOrderObj.calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+pOrderObj.productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 



    }
    

 });



 $("#searchStock").click(function(event){
    
   
 var productId = $('#productId').val();

    $.ajax({
                  url: "http://localhost:9090/stock/code/"+productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                          
                        var tableData ="";
                           for (let i = 0; i < result.length; i++) {
                               console.log(result[i].pincode);
                                tableData = tableData+'<tr><th scope="row">'+result[i].stockId+'</th><td>'+result[i].invoice+'</td><td>'+result[i].productId+
                                  '</td><td>'+result[i].productName+'</td><td>'+result[i].receivedQnty+'</td><td>'+
                                  result[i].sentQnty+'</td><td> <a href = editStockDetails.html?productId='+result[i].stockId+'>Edit</a></td></tr>';                     
                          }     
      
                         $('#stockData').html(tableData);
      
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
});




$("#editStock").click(function(event) {
    event.preventDefault();
var x = $("form").serializeArray();
var obj ={}
$.each(x, function(i, field) {
obj[field.name] = field.value;
          console.log(field.name + ":"
                    + field.value + " ");
});


console.log(obj);

     $.ajax({
          url: "http://localhost:9090/stock", 
         type: "PUT",
         dataType: "json",
         contentType: "application/json; charset=utf-8",
         data: JSON.stringify(obj),
        success: function (result) {
                   console.log(result);
                    var url = "/stocklist.html";
                   $(location).attr('href',url);
         },
        error: function (err) {
            console.log(err);

       }
   }); 
}); 


$("#addstock").click(function(event) {
    event.preventDefault();
var x = $("form").serializeArray();
var obj ={}
$.each(x, function(i, field) {
obj[field.name] = field.value;
          console.log(field.name + ":"
                    + field.value + " ");

});
 var stName = obj.productName;
var  str = stName.split("?");
var stockObj={}
stockObj.invoice = obj.invoice;
stockObj.productId = str[0];
stockObj.productName = str[1];
stockObj.receivedQnty = parseInt(obj.receivedQnty);

console.log(obj);

     $.ajax({
          url: "http://localhost:9090/stock", 
         type: "POST",
         dataType: "json",
         contentType: "application/json; charset=utf-8",
         data: JSON.stringify(stockObj),
        success: function (result) {
                   console.log(result);      
                    var url = "/stocklist.html";
                   $(location).attr('href',url);
         },
        error: function (err) {
            console.log(err);

       }
   }); 
});   



});


 function deleteProdutArryObj(productId){
    console.log("######### delete productID "+productId);

     var productAryList = JSON.parse(sessionStorage.getItem("orderProductArry"));
       var index ;
    if(productAryList.length>0){
      for(let i =0;i<productAryList.length;i++){

          if(productAryList[i].productId == productId){
                     index = i;
                    break;
                }
      }
     productAryList.splice(index, 1);
    }
     sessionStorage.setItem("orderProductArry", JSON.stringify(productAryList));

     var tableData="";
                     for (let i = 0; i < productAryList.length; i++) {
                    tableData = tableData+'<tr><th scope="row">'+i+'</th>'+'<td>'+productAryList[i].productName+
                                        '</td><td>'+productAryList[i].productCode+'</td><td>'+productAryList[i].productBasePrice+'</td><td>'+ productAryList[i].qnty+'</td><td>'+
                                        productAryList[i].calualteAmount+'</td><td> <button onclick="deleteProdutArryObj('+productAryList[i].productId+')"> Delete</button></td></tr>';
                           
               
                        $("#orderRelatedProductData").html(tableData);

                    }
        if(productAryList.length ==0){
            $("#orderRelatedProductData").html(tableData); 
        }

 }

function getCustomerDataById(){
    
    var urlParams = new URLSearchParams(window.location.search);
    var  customerId =urlParams.get('customerId')
     console.log(customerId);

    $.ajax({
                  url: "http://localhost:9090/cust/"+customerId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                 $("#customerId").val(result.customerId);
                 $("#customerName").val(result.customerName);

                 $("#email").val(result.email);
                 $("#mobileNumber").val(result.mobileNumber);
                 $("#GSTNumber").val(result.gstnumber);
                 $("#address").val(result.address);
                 $("#companyName").val(result.companyName);
                 $("#department").val(result.department);
                 $("#city").val(result.city);
                 $("#pincode").val(result.pincode);
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

}



function  getCustomerData(){
    $.ajax({
                  url: "http://localhost:9090/cust", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                    localStorage.setItem("customerList", JSON.stringify(result));
                   var tableData ="";
                     for (let i = 0; i < result.length; i++) {
                         console.log(result[i].pincode);
                          tableData = tableData+'<tr><th scope="row">'+result[i].customerId+'</th>'+'<td>'+result[i].customerName+
                            '</td><td>'+result[i].email+'</td><td>'+result[i].mobileNumber+'</td><td>'+
                            result[i].gstnumber+'</td><td>'+result[i].companyName+'</td><td>'+result[i].department+'</td><td>'+
                            result[i].address+'</td><td>'+result[i].city+'</td><td>'+result[i].pincode+'</td><td> <a href = editCustomer.html?customerId='+result[i].customerId+'> Edit</a></td></tr>';                     
                    }     

                   $('#customerData').html(tableData);


                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}


function getProductData(){
    $.ajax({
                  url: "http://localhost:9090/product", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                           localStorage.setItem("productList", JSON.stringify(result));
                        var tableData ="";
                           for (let i = 0; i < result.length; i++) {
                               console.log(result[i].pincode);
                                tableData = tableData+'<tr><th scope="row">'+result[i].productId+'</th>'+'<td>'+result[i].productName+
                                  '</td><td>'+result[i].productCode+'</td><td>'+result[i].hsn+'</td><td>'+
                                  result[i].pack+'</td><td>'+result[i].basePrice+'</td><td>'+result[i].mrpPrice+'</td><td>'+
                                  result[i].stockQunty+'</td><td> <a href = editproductDetails.html?productId='+result[i].productId+'>Edit</a></td></tr>';                     
                          }     
      
                         $('#productData').html(tableData);
      
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}


function getOrderData(){
    $.ajax({
                  url: "http://localhost:9090/order", 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                           localStorage.setItem("orderList", JSON.stringify(result));
                             var tableData ="";
                     for (let i = 0; i < result.length; i++) {
                         
                          tableData = tableData+'<tr><th scope="row">'+result[i].oriderId+'</th>'+'<td>'+result[i].customerName+
                            '</td><td>'+result[i].gstPerCentage+'</td><td>'+result[i].csgstAmount+'</td><td>'+
                            result[i].sgstAmount+'</td><td>'+result[i].totalGrossAmount+'</td><td>'+result[i].netAmount+'</td><td>'+
                            result[i].netAfterRemovingTransportAmount+'</td><td>'+result[i].status+'</td><td> <a href = invoice.html?orderId='+result[i].oriderId+'> Show</a></td></tr>';                     
                    }     

                   $('#orderData').html(tableData);

                 },
                error: function (err) {
                    console.log(err);

               }
           }); 
}

function loadOrderSetup(){

if(window.location == "http://localhost:8081/orders.html"){
    var orderProductArry =[];
    var customerOptionData ="";
    var productOptionData ="";
    var finalObj={};
     sessionStorage.setItem("createOrdeObj", JSON.stringify(finalObj));
    

   var custObj ={};
   sessionStorage.setItem("selectedCustomerId", JSON.stringify(custObj));
    sessionStorage.setItem("orderProductArry", JSON.stringify(orderProductArry));
     var productAryList = JSON.parse(localStorage.getItem("productList"));
      
    var customerListData = JSON.parse(localStorage.getItem("customerList"));

       for (let i = 0; i < customerListData.length; i++) {
                 
                 customerOptionData = customerOptionData+ '<option value="'+customerListData[i].customerId+'?'+customerListData[i].customerName+'">'+customerListData[i].companyName+'</option>';

       }
 
       for (let i = 0; i < productAryList.length; i++) {
                 
                 productOptionData = productOptionData+ '<option value="'+productAryList[i].productId+'">'+productAryList[i].productName+'</option>';

       }
       $("#showButton").hide();
       $("#showAllValues").hide();
       $("#showAllValues1").hide();
        $("#showAllValues2").hide();
        $("#showHRAfterNetPayAmount").hide();
        $('#showHRAfterAmountCal').hide();
       $('#customerNameList').append(customerOptionData);

       $('#productNameList').append(productOptionData);

   }
}

function getProviderDataByIdForProduct(){
    
    var urlParams = new URLSearchParams(window.location.search);
    var  productId =urlParams.get('productId')
     console.log(productId);

    $.ajax({
                  url: "http://localhost:9090/product/"+productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                 $("#productId").val(result.productId);
                 $("#productName").val(result.productName);
                 $("#productCode").val(result.productCode);
                 $("#hsn").val(result.hsn);
                 $("#pack").val(result.pack);
                 $("#basePrice").val(result.basePrice);
                 $("#mrpPrice").val(result.mrpPrice);
                 $("#stockQunty").val(result.stockQunty);
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

}


function loadInvoiceInformation(){
     var urlParams = new URLSearchParams(window.location.search);
    var  orderId =urlParams.get('orderId');
   // if(window.location == "http://localhost:8081/invoice.html"){

        $.ajax({
                  url: "http://localhost:9090/order/"+orderId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                
                var customerObj = result.customer;
                var orderDetailsObj = result.orderRSPDetails;
                var orderObj  = result.orders;


               var staticData ='<thead><tr><th colspan="11"><table><tbody><tr><td>GSTIN :37AMMPG5495M2Z8</td></tr>'+
               '<tr> <center>TAX INVOICE</center></tr><tr><center><h2>SAI RAM ENTERPRISES</h2></center></tr>'+
               '<tr><center>#FF4,20-3-/48,Padmavathi Residency,Gattarattaiah Street- Ayodhya Nagar</center>'+
               '</tr><tr><center><h5>VIJAYAWADA-520003 Cell : <b>8897712218</b> </h5></center>'+
               '</tr> </tbody></table></th></tr>';



              
                var tableHeader='<thead><tr><th scope="col">#</th><th scope="col">Mnf</th><th scope="col">ProductName</th><th scope="col">HSnCode</th>'+
                      '<th scope="col">Pack</th><th scope="col">Qty</th><th scope="col">Rate</th><th scope="col">CGst%</th>'+
                      '<th scope="col">SGst%</th><th scope="col">Amount</th> <th scope="col">MRP</th></tr> </thead>'+
                      '<tbody id="productRelatedOrderInfo">';


                var dateObj = (new Date()).toISOString().split('T')[0];
                var tableData ="";
                tableData = tableData+'<tr><th colspan="11"><table class="table table-borderless"><tbody><tr><td> To :'+
                customerObj.companyName+'</br>'+customerObj.customerName+'</td><td> GST : '+customerObj.gstnumber+"</td><td> INVOICE NO :"+orderObj.oriderId+'</td></tr><tr><td> Address :'+
                customerObj.address+','+customerObj.city+'</td><td> Mobile Number : '+customerObj.mobileNumber+"</td><td> Date :"+dateObj+'</td></tr><tr><td> PinCode : '+customerObj.pincode+'</td></tr>'+
               '</tbody></table></th></tr></thead>';
                               
                   
                
                var orderDetailsData ="";
                var  gstPercentage =  (parseFloat(orderObj.gstPerCentage)/2).toFixed(2);
                 for (let i = 0; i < orderDetailsObj.length; i++) {
                         var validatePrice =  orderDetailsObj[i].orderDetails.modifiedPrice == 0 ? orderDetailsObj[i].orderDetails.productBasePrice : orderDetailsObj[i].orderDetails.modifiedPrice;
                         console.log(validatePrice);
                          var rowNum = i+1;
                          orderDetailsData = orderDetailsData+'<tr><th scope="row">'+rowNum+'</th>'+'<td>'+customerObj.companyName+'</td><td>'+orderDetailsObj[i].produt.productName+
                            '</td><td>'+orderDetailsObj[i].produt.hsn+'</td><td>'+orderDetailsObj[i].produt.pack+'</td><td>'+
                            orderDetailsObj[i].orderDetails.qnty+'</td><td>'+validatePrice+'</td><td>'+gstPercentage+"%"+'</td><td>'+
                            gstPercentage+"%"+'</td><td>'+orderDetailsObj[i].orderDetails.calualteAmount+'</td><td>'+orderDetailsObj[i].produt.mrpPrice+'</td></tr>';                     
                    }   

              

             var billingData="";

             var totalGstPercentage =parseFloat(orderObj.gstPerCentage).toFixed(2);
             var grossAmount = orderObj.totalGrossAmount;
             var discountAmount = 0;
             var AdjAmt =0;
             var csgAmount  = orderObj.csgstAmount;
             var sgstAmount = orderObj.sgstAmount;
             var netAmount  = "&#8377;"+" "+orderObj.netAmount;
                  
             billingData = billingData +'<th colspan="5"><table class="table table-borderless"><tbody> <tr><td>GST% :</td><td>'+
             totalGstPercentage+'</td></tr><tr><td> TaxableAmount :</td><td>'+(csgAmount+sgstAmount)+'</td></tr><tr><td> CGST Tax :</td><td>'+csgAmount+'</td></tr><tr><td> SGST Tax :</td><td>'+sgstAmount+'</td></tr></tbody></table></th>';
         


              var totalAmountInfo ="";


              totalAmountInfo = totalAmountInfo+'<th colspan="6"><table class="table table-borderless"><tbody><tr><td>Gross Amount :</td><td>'+
              grossAmount+'</td></tr><tr><td>Discount :</td><td>'+discountAmount+'</td></tr><tr><td>Net Amount :</td><td>'+
              netAmount+'</td></tr> </tbody> </table></th>';

            

              var notesInfo ="";
              notesInfo=notesInfo+'<tr> <th colspan="4"><h4>TERMS:</h4>Good once Sold Cannot be taken back or exchanged.<br>'+
              ' We are not responsible for any damage or shortage when</br>'+'once goods leave our premisses.'+' Please Pay by A/C.Paypee Cheques Only.'+" "+
              '</th><th colspan="3"><p><center>Customer Signature </center></p></th><th colspan="4"><p><center>For SAIRAM ENTERPRISES </center></p></th>'+
              ' </tr></tbody>';

             





                var totalData = staticData+tableData+tableHeader+orderDetailsData+billingData+totalAmountInfo+notesInfo;


               console.log(totalData);

               $('#invoiceInfo').html(totalData);
                
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

    
}


function getOrderCountDetails(){

   $.ajax({
                  url: "http://localhost:9090/order/getOrderCount",
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);

                 var aceptCount = result.ACCEPTED;
                 var completeCount = result.COMPLETED;
                 var inProgessCount = result.IN_PROGRESS;

                 $('#acceptedCount').html("ACCEPTED ORDERS :"+aceptCount);
                 $('#progresCount').html("IN_PROGRESS ORDERS :"+inProgessCount);
                 $('#completedCount').html("COMPLETED ORDERS :"+completeCount);
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           });    
}


function loadBasicProductInfo(){


    var result = JSON.parse(localStorage.getItem("productList"));

      var tableData="";
     for (let i = 0; i < result.length; i++) {
                              
        tableData = tableData+'<tr><th scope="row">'+result[i].productName+'</th>'+'<td>'+result[i].productCode+
       '</td><td>'+result[i].mrpPrice+'</td></tr>';                     

     }     

     $('#basicProductInfo').html(tableData);
}


function loadStockSetup(){
    var productIDData ="";
    var productNameData ="";
   
     var productAryList = JSON.parse(localStorage.getItem("productList"));
 
     for (let i = 0; i < productAryList.length; i++) {
                 
        productNameData = productNameData+ '<option value="'+productAryList[i].productId+"?"+productAryList[i].productName+'">'+productAryList[i].productName+'</option>';

     }
      
                
       $('#productStockNameList').append(productNameData);
}



function getStockDataById(){
    
    var urlParams = new URLSearchParams(window.location.search);
    var  customerId =urlParams.get('customerId')
     console.log(customerId);

    $.ajax({
                  url: "http://localhost:9090/stock/"+productId, 
                 type: "GET",
                 dataType: "json",
                 contentType: "application/json; charset=utf-8",
                success: function (result) {
                           console.log(result);
                 $("#Invoice").val(result.Invoice);
                 $("#productId").val(result.productId);

                 $("#productName").val(result.productNameList);
                 $("#receivedQnty").val(result.receivedQnty);
                           
                 },
                error: function (err) {
                    console.log(err);

               }
           }); 

}
